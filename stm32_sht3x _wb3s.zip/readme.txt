使用ST的NUCLEO-L476RG开发板，温湿度传感器模块（SHT30)，涂鸦云模组WB3S；
通过APP上实时显示温湿度数据。

MCU通过串口1和涂鸦云模组WB3S进行通信。
MCU通过串口2打印日志。

ST nucleo-L476RG development board, T/H sensor module (SHT30), tuya cloud module WB3S;  
Real-time display of temperature and humidity data through APP.
 
MCU communicates with tuya cloud module WB3S through serial port 1.  
The MCU generates logs over serial port 2.  
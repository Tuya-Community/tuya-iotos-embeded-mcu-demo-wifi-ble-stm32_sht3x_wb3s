#ifndef __CONNECT_WIFI_H
#define __CONNECT_WIFI_H

void Connect_Wifi(void);

#define WIFI_LED_GPIO_Port  GPIOA
#define WIFI_LED_Pin   GPIO_PIN_5
#define WIFI_KEY_GPIO_Port  GPIOC
#define WIFI_KEY_Pin   GPIO_PIN_13
#endif





























